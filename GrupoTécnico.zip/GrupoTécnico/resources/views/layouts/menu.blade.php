<li class="{{ Request::is('agendas*') ? 'active' : '' }}">
    <a href="{!! route('agendas.index') !!}"><i class="glyphicon glyphicon-user"></i><span>Agendas</span></a>
</li>

<li class="{{ Request::is('rentas*') ? 'active' : '' }}">
    <a href="{!! route('rentas.index') !!}"><i class="glyphicon glyphicon-usd"></i><span>Rentas</span></a>
</li>
<li class="{{ Request::is('nominas*') ? 'active' : '' }}">
    <a href="{!! route('nominas.index') !!}"><i class="glyphicon glyphicon-piggy-bank"></i><span>Nominas</span></a>
</li>

<li class="{{ Request::is('notas*') ? 'active' : '' }}">
    <a href="{!! route('notas.index') !!}"><i class="glyphicon glyphicon-book"></i><span>Notas</span></a>
</li>

<li class="">
    <a href="{{ route('logout') }}" 
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
        <i class="fa fa-circle-o text-red"></i><span>Cerrar sesión</span>
    </a>
<li>