<div class="table-responsive">
    <table class="table" id="nominas-table">
        <thead>
            <tr>
                <th>Fecha Inicio</th>
        <th>Fecha De Pago</th>
        <th>Nombre Empleado</th>
        <th>Importe</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($nominas as $nominas)
            <tr>
                <td>{!! $nominas->Fecha_inicio !!}</td>
            <td>{!! $nominas->Fecha_de_Pago !!}</td>
            <td>{!! $nominas->Nombre_empleado !!}</td>
            <td>{!! $nominas->importe !!}</td>
                <td>
                    {!! Form::open(['route' => ['nominas.destroy', $nominas->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! route('nominas.show', [$nominas->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="{!! route('nominas.edit', [$nominas->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Confirmar Eliminación')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
