<!-- Fecha Inicio Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Fecha_inicio', 'Fecha Inicio:') !!}
    {!! Form::date('Fecha_inicio', null, ['class' => 'form-control']) !!}
</div>

<!-- Fecha De Pago Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Fecha_de_Pago', 'Fecha De Pago:') !!}
    {!! Form::date('Fecha_de_Pago', null, ['class' => 'form-control']) !!}
</div>

<!-- Nombre Empleado Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Nombre_empleado', 'Nombre Empleado:') !!}
    {!! Form::text('Nombre_empleado', null, ['class' => 'form-control']) !!}
</div>

<!-- Importe Field -->
<div class="form-group col-sm-6">
    {!! Form::label('importe', 'Importe:') !!}
    {!! Form::text('importe', null, ['class' => 'form-control']) !!}
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Guardar', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('nominas.index') !!}" class="btn btn-default">Cancelar</a>
</div>
