<div class="col-md-10">
                        <!-- Widget: user widget style 1 -->
    <div class="box box-widget widget-user">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <div class="widget-user-header bg-black" style="background: url('../dist/img/photo1.png') center center;">
            <h3 class="widget-user-username">{!! $nominas->Nombre_empleado !!}</h3>
            <h5 class="widget-user-desc"></h5>
        </div>
        <div class="widget-user-image">
            <img class="img-circle" src="{{asset('img/empleado.png')}}" alt="User Avatar">
        </div>
        <div class="box-footer">
            <div class="row">
                <div class="col-sm-4 border-right">
                    <div class="description-block">
                    <span class="description-text">Fecha</span>
                        <h5 class="description-header">{!! $nominas->Fecha_inicio !!}/h5>
                        
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-4 border-right">
                    <div class="description-block">
                    <span class="description-text">Fecha de pago</span>
                        <h5 class="description-header">{!! $nominas->Fecha_de_Pago !!}</h5>
                        
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-4">
                    <div class="description-block">
                    <span class="description-text">PAGO TOTAL</span>
                        <h5 class="description-header">{!! $nominas->importe !!}</h5>
                        
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </div>
</div>

