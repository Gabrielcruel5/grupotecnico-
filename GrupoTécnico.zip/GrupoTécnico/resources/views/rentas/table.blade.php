<div class="table-responsive">
    <table class="table" id="rentas-table">
        <thead>
            <tr>
                <th>Fecha</th>
                 <th>Importe</th>
                <th colspan="3">Opción</th>
            </tr>
        </thead>
        <tbody>
        @foreach($rentas as $rentas)
            <tr>
                <td>{!! $rentas->Fecha !!}</td>
            <td>{!! $rentas->importe !!}</td>
                <td>
                    {!! Form::open(['route' => ['rentas.destroy', $rentas->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! route('rentas.show', [$rentas->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="{!! route('rentas.edit', [$rentas->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Confirmar Eliminación?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
