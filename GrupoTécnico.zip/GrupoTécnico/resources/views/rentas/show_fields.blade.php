<div class="col-md-10 col-sm-9 col-xs-20">
    <div class="info-box bg-green">
        <span class="info-box-icon"><i class="glyphicon glyphicon-usd"></i></span>

        <div class="info-box-content">
            <span class="info-box-text">Id :{!! $rentas->id !!} </span>
            <span class="info-box-text">Fecha :{!! $rentas->Fecha !!} </span>
            <span class="info-box-number">Importe :{!! $rentas->importe !!}</span>
        </div>
        <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
</div>


