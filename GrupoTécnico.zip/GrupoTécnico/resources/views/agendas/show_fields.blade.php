<div class="col-md-10">
                        <!-- Widget: user widget style 1 -->
    <div class="box box-widget widget-user-2">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <div class="widget-user-header bg-yellow">
            <div class="widget-user-image">
                <img class="img-circle" src="{{asset('img/contacto.png')}}" alt="User Avatar">
            </div>
            <!-- /.widget-user-image -->
            <h3 class="widget-user-username">{!! $agenda->nombre !!}</h3>
            <h5 class="widget-user-desc"></h5>
        </div>
        <div class="box-footer no-padding">
            <ul class="nav nav-stacked">
                <li><a href="#">ID <span class="pull-right badge bg-blue">{!! $agenda->id !!}</span></a></li>
                <li><a href="#">Telefono <span class="pull-right badge bg-aqua">{!! $agenda->telefono !!}</span></a></li>
                <li><a href="#">Dirección <span class="pull-right badge bg-green">{!! $agenda->direccion !!}</span></a></li>
            </ul>
        </div>
    </div>
</div>



