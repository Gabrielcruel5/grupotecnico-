<!-- Fecha Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Fecha', 'Fecha:') !!}
    {!! Form::date('Fecha', null, ['class' => 'form-control']) !!}
</div>

<!-- Nombre Cliente Field -->
<div class="form-group col-sm-6">
    {!! Form::label('nombre_Cliente', 'Nombre Cliente:') !!}
    {!! Form::text('nombre_Cliente', null, ['class' => 'form-control']) !!}
</div>

<!-- Direccion Cliente Field -->
<div class="form-group col-sm-6">
    {!! Form::label('direccion_cliente', 'Direccion Cliente:') !!}
    {!! Form::text('direccion_cliente', null, ['class' => 'form-control']) !!}
</div>

<!-- Concepto Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Concepto', 'Concepto:') !!}
    {!! Form::text('Concepto', null, ['class' => 'form-control']) !!}
</div>

<!-- Importe Field -->
<div class="form-group col-sm-6">
    {!! Form::label('Importe', 'Importe:') !!}
    {!! Form::text('Importe', null, ['class' => 'form-control']) !!}
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Guardar', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('notas.index') !!}" class="btn btn-default">Cancelar</a>
</div>
