<div class="col-md-11">
                        <!-- Widget: user widget style 1 -->
    <div class="box box-widget widget-user">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <div class="widget-user-header bg-aqua-active">
            <h3 class="widget-user-username">Grupo Técnico</h3>
            <h5 class="widget-user-desc">Nota de remision</h5>
            <h5 class="widget-user-desc">Tel : 56148030 / 56685149</h5>
            <h5 class="widget-user-desc">Dirección : Alta Tensión #118 Olivar del Conde</h5>
        </div>
        <div class="widget-user-image">
            <img class="img-circle" src="{{asset('img/logo.jpg')}}" alt="User Avatar">
        </div>
        <div class="box-footer">
            <div class="row">
                <div class="col-sm-4 border-right">
                    <div class="description-block">
                        
                        <span class="description-text">Nota No.</span>
                        <h5 class="description-header">{!! $notas->id !!}</h5>
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-4 border-right">
                    <div class="description-block">
                    <span class="description-text">Cliente</span>
                        <h5 class="description-header">{!! $notas->nombre_Cliente !!}</h5>
                        
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-4">
                    <div class="description-block">
                    <span class="description-text">Fecha</span>
                        <h5 class="description-header">{!! $notas->Fecha !!}</h5>
                        
                    </div>
                    <!-- /.description-block -->
                </div>
                <!-- /.col -->
            </div>
           
            <div class="form-group">
                {!! Form::label('direccion_cliente', 'Direccion Cliente:') !!}
                <p>{!! $notas->direccion_cliente !!}</p>
            </div>
            <!-- Concepto Field -->
            <div class="form-group">
                {!! Form::label('Concepto', 'Concepto:') !!}
                <p>{!! $notas->Concepto !!}</p>
            </div>

            <!-- Importe Field -->
            <div class="form-group">
                {!! Form::label('Importe', 'Importe:') !!}
                <p>{!! $notas->Importe !!}</p>
            </div>
        </div>
        <div class="widget-user-header bg-aqua-active">
            <h5 class="widget-user-desc"></h5>
            <h3 class="widget-user-username">Nota de remision y garantia del servicio.</h3>
        </div>
    </div>

</div>    


