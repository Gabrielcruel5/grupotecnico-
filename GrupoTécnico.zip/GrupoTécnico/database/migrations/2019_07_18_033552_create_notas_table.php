<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateNotasTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notas', function (Blueprint $table) {
            $table->increments('id');
            $table->time('Fecha_nota');
            $table->string('nombre_Cliente');
            $table->string('direccion_cliente', 100);
            $table->string('Concepto', 300);
            $table->decimal('Importe');
            $table->date('uptimed_at');
            $table->date('created_at');
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('notas');
    }
}
