<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Notas
 * @package App\Models
 * @version July 18, 2019, 3:39 am UTC
 *
 * @property time Fecha
 * @property string nombre_Cliente
 * @property string direccion_cliente
 * @property string Concepto
 * @property float Importe
 */
class Notas extends Model
{
    use SoftDeletes;

    public $table = 'notas';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'Fecha',
        'nombre_Cliente',
        'direccion_cliente',
        'Concepto',
        'Importe'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'nombre_Cliente' => 'string',
        'direccion_cliente' => 'string',
        'Concepto' => 'string',
        'Importe' => 'float'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'Fecha' => 'required',
        'nombre_Cliente' => 'required',
        'direccion_cliente' => 'required',
        'Concepto' => 'required',
        'Importe' => 'required'
    ];

    
}
