<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Rentas
 * @package App\Models
 * @version July 18, 2019, 3:07 am UTC
 *
 * @property time Fecha
 * @property float importe
 */
class Rentas extends Model
{
    use SoftDeletes;

    public $table = 'rentas';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'Fecha',
        'importe'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'importe' => 'float'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'Fecha' => 'required',
        'importe' => 'required'
    ];

    
}
