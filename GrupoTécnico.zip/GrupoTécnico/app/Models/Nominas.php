<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Nominas
 * @package App\Models
 * @version July 18, 2019, 3:14 am UTC
 *
 * @property time Fecha_inicio
 * @property time Fecha_de_Pago
 * @property string Nombre_empleado
 * @property float importe
 */
class Nominas extends Model
{
    use SoftDeletes;

    public $table = 'nominas';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'Fecha_inicio',
        'Fecha_de_Pago',
        'Nombre_empleado',
        'importe'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'Nombre_empleado' => 'string',
        'importe' => 'float'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'Fecha_inicio' => 'required',
        'Fecha_de_Pago' => 'required',
        'Nombre_empleado' => 'required',
        'importe' => 'required'
    ];

    
}
