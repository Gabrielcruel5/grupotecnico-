<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateNominasRequest;
use App\Http\Requests\UpdateNominasRequest;
use App\Repositories\NominasRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Response;

class NominasController extends AppBaseController
{
    /** @var  NominasRepository */
    private $nominasRepository;

    public function __construct(NominasRepository $nominasRepo)
    {
        $this->nominasRepository = $nominasRepo;
    }

    /**
     * Display a listing of the Nominas.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $nominas = $this->nominasRepository->all();

        return view('nominas.index')
            ->with('nominas', $nominas);
    }

    /**
     * Show the form for creating a new Nominas.
     *
     * @return Response
     */
    public function create()
    {
        return view('nominas.create');
    }

    /**
     * Store a newly created Nominas in storage.
     *
     * @param CreateNominasRequest $request
     *
     * @return Response
     */
    public function store(CreateNominasRequest $request)
    {
        $input = $request->all();

        $nominas = $this->nominasRepository->create($input);

        Flash::success('Registro guardado.');

        return redirect(route('nominas.index'));
    }

    /**
     * Display the specified Nominas.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $nominas = $this->nominasRepository->find($id);

        if (empty($nominas)) {
            Flash::error('Nominas not found');

            return redirect(route('nominas.index'));
        }

        return view('nominas.show')->with('nominas', $nominas);
    }

    /**
     * Show the form for editing the specified Nominas.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $nominas = $this->nominasRepository->find($id);

        if (empty($nominas)) {
            Flash::error('Nominas not found');

            return redirect(route('nominas.index'));
        }

        return view('nominas.edit')->with('nominas', $nominas);
    }

    /**
     * Update the specified Nominas in storage.
     *
     * @param int $id
     * @param UpdateNominasRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateNominasRequest $request)
    {
        $nominas = $this->nominasRepository->find($id);

        if (empty($nominas)) {
            Flash::error('Nominas not found');

            return redirect(route('nominas.index'));
        }

        $nominas = $this->nominasRepository->update($request->all(), $id);

        Flash::success('Registro actualizado.');

        return redirect(route('nominas.index'));
    }

    /**
     * Remove the specified Nominas from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $nominas = $this->nominasRepository->find($id);

        if (empty($nominas)) {
            Flash::error('Nominas not found');

            return redirect(route('nominas.index'));
        }

        $this->nominasRepository->delete($id);

        Flash::success('Registro eliminado.');

        return redirect(route('nominas.index'));
    }
}
