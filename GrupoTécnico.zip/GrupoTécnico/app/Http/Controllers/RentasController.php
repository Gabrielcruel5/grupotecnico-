<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateRentasRequest;
use App\Http\Requests\UpdateRentasRequest;
use App\Repositories\RentasRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Response;

class RentasController extends AppBaseController
{
    /** @var  RentasRepository */
    private $rentasRepository;

    public function __construct(RentasRepository $rentasRepo)
    {
        $this->rentasRepository = $rentasRepo;
    }

    /**
     * Display a listing of the Rentas.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $rentas = $this->rentasRepository->all();

        return view('rentas.index')
            ->with('rentas', $rentas);
    }

    /**
     * Show the form for creating a new Rentas.
     *
     * @return Response
     */
    public function create()
    {
        return view('rentas.create');
    }

    /**
     * Store a newly created Rentas in storage.
     *
     * @param CreateRentasRequest $request
     *
     * @return Response
     */
    public function store(CreateRentasRequest $request)
    {
        $input = $request->all();

        $rentas = $this->rentasRepository->create($input);

        Flash::success('Renta registrada exitosamente.');

        return redirect(route('rentas.index'));
    }

    /**
     * Display the specified Rentas.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $rentas = $this->rentasRepository->find($id);

        if (empty($rentas)) {
            Flash::error('Rentas not found');

            return redirect(route('rentas.index'));
        }

        return view('rentas.show')->with('rentas', $rentas);
    }

    /**
     * Show the form for editing the specified Rentas.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $rentas = $this->rentasRepository->find($id);

        if (empty($rentas)) {
            Flash::error('Rentas not found');

            return redirect(route('rentas.index'));
        }

        return view('rentas.edit')->with('rentas', $rentas);
    }

    /**
     * Update the specified Rentas in storage.
     *
     * @param int $id
     * @param UpdateRentasRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateRentasRequest $request)
    {
        $rentas = $this->rentasRepository->find($id);

        if (empty($rentas)) {
            Flash::error('Rentas not found');

            return redirect(route('rentas.index'));
        }

        $rentas = $this->rentasRepository->update($request->all(), $id);

        Flash::success('Renta actualizada.');

        return redirect(route('rentas.index'));
    }

    /**
     * Remove the specified Rentas from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $rentas = $this->rentasRepository->find($id);

        if (empty($rentas)) {
            Flash::error('Rentas not found');

            return redirect(route('rentas.index'));
        }

        $this->rentasRepository->delete($id);

        Flash::success('Renta eliminada con exito.');

        return redirect(route('rentas.index'));
    }
}
