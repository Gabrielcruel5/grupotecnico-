<?php

namespace App\Repositories;

use App\Models\Nominas;
use App\Repositories\BaseRepository;

/**
 * Class NominasRepository
 * @package App\Repositories
 * @version July 18, 2019, 3:14 am UTC
*/

class NominasRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'Fecha_inicio',
        'Fecha_de_Pago',
        'Nombre_empleado',
        'importe'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Nominas::class;
    }
}
