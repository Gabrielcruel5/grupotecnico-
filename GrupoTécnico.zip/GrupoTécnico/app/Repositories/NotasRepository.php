<?php

namespace App\Repositories;

use App\Models\Notas;
use App\Repositories\BaseRepository;

/**
 * Class NotasRepository
 * @package App\Repositories
 * @version July 18, 2019, 3:39 am UTC
*/

class NotasRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'Fecha',
        'nombre_Cliente',
        'direccion_cliente',
        'Concepto',
        'Importe'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Notas::class;
    }
}
