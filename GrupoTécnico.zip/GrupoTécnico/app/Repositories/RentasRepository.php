<?php

namespace App\Repositories;

use App\Models\Rentas;
use App\Repositories\BaseRepository;

/**
 * Class RentasRepository
 * @package App\Repositories
 * @version July 18, 2019, 3:07 am UTC
*/

class RentasRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'Fecha',
        'importe'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Rentas::class;
    }
}
