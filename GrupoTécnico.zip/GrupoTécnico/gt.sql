-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-07-2019 a las 01:45:52
-- Versión del servidor: 5.7.26-0ubuntu0.19.04.1
-- Versión de PHP: 7.2.19-0ubuntu0.19.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gt`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agendas`
--

CREATE TABLE `agendas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `agendas`
--

INSERT INTO `agendas` (`id`, `nombre`, `direccion`, `telefono`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Alejandro1', 'palmas', '5515200416', '2019-07-18 08:06:06', '2019-07-18 09:28:38', NULL),
(2, 'Alejandro', 'palmas', '5515200416', '2019-07-18 09:25:22', '2019-07-18 09:50:23', '2019-07-18 09:50:23'),
(3, 'sra rosa', 'calandria 19 4', '55953872', '2019-07-19 01:36:11', '2019-07-19 01:36:11', NULL),
(4, 'carmen fores', 'tlanepantla', '53614972', '2019-07-19 01:37:09', '2019-07-19 01:37:09', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_07_18_030457_create_agendas_table', 2),
(4, '2019_07_18_030736_create_rentas_table', 3),
(5, '2019_07_18_031439_create_nominas_table', 4),
(6, '2019_07_18_032019_create_notas_table', 5),
(7, '2019_07_18_032917_create_notas_table', 6),
(8, '2019_07_18_033552_create_notas_table', 7),
(9, '2019_07_18_033943_create_notas_table', 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nominas`
--

CREATE TABLE `nominas` (
  `id` int(10) UNSIGNED NOT NULL,
  `Fecha_inicio` date NOT NULL,
  `Fecha_de_Pago` date NOT NULL,
  `Nombre_empleado` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `importe` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `nominas`
--

INSERT INTO `nominas` (`id`, `Fecha_inicio`, `Fecha_de_Pago`, `Nombre_empleado`, `importe`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2019-07-15', '2019-07-21', 'gabriel', '5500.00', '2019-07-18 08:18:43', '2019-07-18 08:18:43', NULL),
(2, '2019-07-15', '2019-07-21', 'gabriel', '2500.00', '2019-07-18 10:06:28', '2019-07-18 10:06:28', NULL),
(3, '2019-07-22', '2019-07-27', 'gabrielllll', '5000.00', '2019-07-18 10:12:09', '2019-07-18 10:12:24', NULL),
(4, '2019-07-18', '2019-07-18', 'sr raul', '150.00', '2019-07-19 01:38:54', '2019-07-19 01:38:54', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE `notas` (
  `id` int(10) UNSIGNED NOT NULL,
  `Fecha` date NOT NULL,
  `nombre_Cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion_cliente` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Concepto` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Importe` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`id`, `Fecha`, `nombre_Cliente`, `direccion_cliente`, `Concepto`, `Importe`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2019-07-17', 'gabriel', 'palmas', 'plomería en general', '500.00', '2019-07-18 08:41:49', '2019-07-18 08:41:49', NULL),
(2, '2019-07-18', 'Alejandro González Hernández', 'Olivar del conde #122', 'Instalación y mantenimiento eléctrico.', '6200.00', '2019-07-18 22:16:02', '2019-07-18 22:16:02', NULL),
(3, '2019-07-18', 'sra rosa', 'calandria 19 4', 'flotador', '150.00', '2019-07-19 01:40:38', '2019-07-19 01:40:38', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rentas`
--

CREATE TABLE `rentas` (
  `id` int(10) UNSIGNED NOT NULL,
  `Fecha` date NOT NULL,
  `importe` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `rentas`
--

INSERT INTO `rentas` (`id`, `Fecha`, `importe`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2019-07-17', '5500.00', '2019-07-18 08:12:24', '2019-07-18 08:12:24', NULL),
(2, '2019-07-16', '2500.00', '2019-07-18 09:39:31', '2019-07-18 09:50:17', '2019-07-18 09:50:17'),
(3, '2019-07-18', '5000.00', '2019-07-18 09:45:22', '2019-07-18 09:49:31', '2019-07-18 09:49:31'),
(4, '2019-07-18', '5500.00', '2019-07-19 01:37:54', '2019-07-19 01:37:54', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Gabriel González Hernández', 'admin@admin.com', NULL, '$2y$10$2Ga8r5e5FjKIItuuoYdZYOtsCNOxUijGGN1QSph.gceICdPifbrqu', NULL, '2019-07-18 08:05:57', '2019-07-18 08:05:57');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agendas`
--
ALTER TABLE `agendas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nominas`
--
ALTER TABLE `nominas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `rentas`
--
ALTER TABLE `rentas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `agendas`
--
ALTER TABLE `agendas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `nominas`
--
ALTER TABLE `nominas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `notas`
--
ALTER TABLE `notas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `rentas`
--
ALTER TABLE `rentas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
