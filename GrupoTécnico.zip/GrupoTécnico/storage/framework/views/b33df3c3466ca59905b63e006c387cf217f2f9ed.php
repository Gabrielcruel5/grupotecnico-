<li class="<?php echo e(Request::is('agendas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('agendas.index'); ?>"><i class="glyphicon glyphicon-user"></i><span>Agendas</span></a>
</li>

<li class="<?php echo e(Request::is('rentas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('rentas.index'); ?>"><i class="glyphicon glyphicon-usd"></i><span>Rentas</span></a>
</li>
<li class="<?php echo e(Request::is('nominas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('nominas.index'); ?>"><i class="glyphicon glyphicon-piggy-bank"></i><span>Nominas</span></a>
</li>

<li class="<?php echo e(Request::is('notas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('notas.index'); ?>"><i class="glyphicon glyphicon-book"></i><span>Notas</span></a>
</li>

<li class="">
    <a href="<?php echo e(route('logout')); ?>" 
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
        <i class="fa fa-circle-o text-red"></i><span>Cerrar sesión</span>
    </a>
<li><?php /**PATH /home/gabriel/Escritorio/Programación/GrupoTécnico/resources/views/layouts/menu.blade.php ENDPATH**/ ?>