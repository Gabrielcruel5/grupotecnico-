<div class="table-responsive">
    <table class="table" id="nominas-table">
        <thead>
            <tr>
                <th>Fecha Inicio</th>
        <th>Fecha De Pago</th>
        <th>Nombre Empleado</th>
        <th>Importe</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $nominas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nominas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $nominas->Fecha_inicio; ?></td>
            <td><?php echo $nominas->Fecha_de_Pago; ?></td>
            <td><?php echo $nominas->Nombre_empleado; ?></td>
            <td><?php echo $nominas->importe; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['nominas.destroy', $nominas->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('nominas.show', [$nominas->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('nominas.edit', [$nominas->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Confirmar Eliminación')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/gabriel/Escritorio/GrupoTécnico/resources/views/nominas/table.blade.php ENDPATH**/ ?>