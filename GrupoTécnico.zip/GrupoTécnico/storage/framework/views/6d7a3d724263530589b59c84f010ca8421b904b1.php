<!-- Fecha Inicio Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Fecha_inicio', 'Fecha Inicio:'); ?>

    <?php echo Form::date('Fecha_inicio', null, ['class' => 'form-control']); ?>

</div>

<!-- Fecha De Pago Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Fecha_de_Pago', 'Fecha De Pago:'); ?>

    <?php echo Form::date('Fecha_de_Pago', null, ['class' => 'form-control']); ?>

</div>

<!-- Nombre Empleado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Nombre_empleado', 'Nombre Empleado:'); ?>

    <?php echo Form::text('Nombre_empleado', null, ['class' => 'form-control']); ?>

</div>

<!-- Importe Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('importe', 'Importe:'); ?>

    <?php echo Form::text('importe', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('nominas.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH /home/gabriel/Escritorio/GrupoTécnico/resources/views/nominas/fields.blade.php ENDPATH**/ ?>