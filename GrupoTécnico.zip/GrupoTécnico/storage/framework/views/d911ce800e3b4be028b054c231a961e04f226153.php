<div class="table-responsive">
    <table class="table" id="notas-table">
        <thead>
            <tr>
                <th>Fecha</th>
        <th>Nombre Cliente</th>
        <th>Direccion Cliente</th>
        <th>Concepto</th>
        <th>Importe</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $notas->Fecha; ?></td>
            <td><?php echo $notas->nombre_Cliente; ?></td>
            <td><?php echo $notas->direccion_cliente; ?></td>
            <td><?php echo $notas->Concepto; ?></td>
            <td><?php echo $notas->Importe; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['notas.destroy', $notas->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('notas.show', [$notas->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('notas.edit', [$notas->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Confirmar Eliminación?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/gabriel/Escritorio/GrupoTécnico/resources/views/notas/table.blade.php ENDPATH**/ ?>