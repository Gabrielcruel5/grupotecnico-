<div class="col-md-10 col-sm-9 col-xs-20">
    <div class="info-box bg-green">
        <span class="info-box-icon"><i class="glyphicon glyphicon-usd"></i></span>

        <div class="info-box-content">
            <span class="info-box-text">Id :<?php echo $rentas->id; ?> </span>
            <span class="info-box-text">Fecha :<?php echo $rentas->Fecha; ?> </span>
            <span class="info-box-number">Importe :<?php echo $rentas->importe; ?></span>
        </div>
        <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
</div>


<?php /**PATH /home/gabriel/Escritorio/GrupoTécnico/resources/views/rentas/show_fields.blade.php ENDPATH**/ ?>