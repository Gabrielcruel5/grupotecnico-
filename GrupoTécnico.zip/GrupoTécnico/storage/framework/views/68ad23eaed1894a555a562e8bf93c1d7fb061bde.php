<div class="table-responsive">
    <table class="table" id="agendas-table">
        <thead>
            <tr>
                <th>Nombre</th>
        <th>Direccion</th>
        <th>Telefono</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $agenda->nombre; ?></td>
            <td><?php echo $agenda->direccion; ?></td>
            <td><?php echo $agenda->telefono; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['agendas.destroy', $agenda->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('agendas.show', [$agenda->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('agendas.edit', [$agenda->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Confirmar eliminación?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/gabriel/Escritorio/Programación/GrupoTécnico/resources/views/agendas/table.blade.php ENDPATH**/ ?>