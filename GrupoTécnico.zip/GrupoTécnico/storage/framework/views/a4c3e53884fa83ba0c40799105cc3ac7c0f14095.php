<!-- Fecha Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Fecha', 'Fecha:'); ?>

    <?php echo Form::date('Fecha', null, ['class' => 'form-control']); ?>

</div>

<!-- Nombre Cliente Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre_Cliente', 'Nombre Cliente:'); ?>

    <?php echo Form::text('nombre_Cliente', null, ['class' => 'form-control']); ?>

</div>

<!-- Direccion Cliente Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('direccion_cliente', 'Direccion Cliente:'); ?>

    <?php echo Form::text('direccion_cliente', null, ['class' => 'form-control']); ?>

</div>

<!-- Concepto Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Concepto', 'Concepto:'); ?>

    <?php echo Form::text('Concepto', null, ['class' => 'form-control']); ?>

</div>

<!-- Importe Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Importe', 'Importe:'); ?>

    <?php echo Form::text('Importe', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('notas.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH /home/gabriel/Escritorio/GrupoTécnico/resources/views/notas/fields.blade.php ENDPATH**/ ?>